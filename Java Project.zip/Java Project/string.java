public class string {
    public static void main(String [] args) {
        //String s = "String handling";
        //char buf[] = new char[2000];
        //s.getChars(2, 11, buf, 0);
        //System.out.println(buf);

        //String s1 = new String("Good Morning");
        //String s2 = new String("MORNING");
        //System.out.println(s1.regionMatches(5, s2, 0, 3));
        //System.out.println(s1.regionMatches(true, 5 , s2, 0, 6));

        //String s1 = "Hello";
        //String s2 = new String("HELLO");
        //System.out.println(s1.equals(s2));

        //String s1 = "hello";
        //String s2 = "hello";
        //System.out.println(s1.compareTo(s2));

        //String s1 = "             Hello World                 ";
        //System.out.println(s1.substring(5));
        //System.out.println(s1.replace('l','n'));
        //String s2 = s1;
        //System.out.println(s2.trim());
        
        //String s2=s1.trim();
        //System.out.println(s2);
        ///System.out.println(s2.toUpperCase());
        //System.out.println(s2.toLowerCase());

        char letters[] = {'a', 'b', 'c'};
        String s = new String(letters);
        System.out.println(s.length());

        


    }
}
